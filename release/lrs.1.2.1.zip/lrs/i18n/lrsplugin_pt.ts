<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="2.0" language="pt_PT" sourcelanguage="en_GB">
<context>
    <name>LrsDockWidget</name>
    <message>
        <location filename="ui_lrsdockwidget.py" line="456"/>
        <source>LRS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_lrsdockwidget.py" line="459"/>
        <source>Maximum gap between lies to be snapped.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_lrsdockwidget.py" line="458"/>
        <source>Max lines snap</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_lrsdockwidget.py" line="460"/>
        <source>Points layer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_lrsdockwidget.py" line="461"/>
        <source>Lines layer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_lrsdockwidget.py" line="462"/>
        <source>Lines route field</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_lrsdockwidget.py" line="514"/>
        <source>Maximum distance of point from line.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_lrsdockwidget.py" line="515"/>
        <source>Max point distance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_lrsdockwidget.py" line="465"/>
        <source>Measure field</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_lrsdockwidget.py" line="466"/>
        <source>Points route field</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_lrsdockwidget.py" line="468"/>
        <source>Routes selection mode.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_lrsdockwidget.py" line="469"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Map units per measure unit.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_lrsdockwidget.py" line="470"/>
        <source>Measure unit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_lrsdockwidget.py" line="473"/>
        <source>Extrapolate before and after calibration points.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_lrsdockwidget.py" line="472"/>
        <source>Extrapolate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_lrsdockwidget.py" line="474"/>
        <source>Comma separated list of routes to include/exclude.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_lrsdockwidget.py" line="475"/>
        <source>Select</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_lrsdockwidget.py" line="476"/>
        <source>Parallels</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_lrsdockwidget.py" line="477"/>
        <source>Progress label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_lrsdockwidget.py" line="478"/>
        <source>Calibration</source>
        <translation>Calibração</translation>
    </message>
    <message>
        <location filename="ui_lrsdockwidget.py" line="479"/>
        <source>Filter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_lrsdockwidget.py" line="496"/>
        <source>Zoom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_lrsdockwidget.py" line="481"/>
        <source>Add layers of errors to map view</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_lrsdockwidget.py" line="482"/>
        <source>Error layers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_lrsdockwidget.py" line="483"/>
        <source>Quality layer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_lrsdockwidget.py" line="484"/>
        <source>Errors</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_lrsdockwidget.py" line="485"/>
        <source>Route</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_lrsdockwidget.py" line="486"/>
        <source>Measure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_lrsdockwidget.py" line="487"/>
        <source>Coordinates</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_lrsdockwidget.py" line="488"/>
        <source>&lt;coordinates&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_lrsdockwidget.py" line="491"/>
        <source>Buffer around event in map units used for zoom.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_lrsdockwidget.py" line="490"/>
        <source>Zoom buffer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_lrsdockwidget.py" line="492"/>
        <source>Available measures</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_lrsdockwidget.py" line="493"/>
        <source>&lt;measures&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_lrsdockwidget.py" line="494"/>
        <source>Highlight</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_lrsdockwidget.py" line="495"/>
        <source>Center</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_lrsdockwidget.py" line="497"/>
        <source>Locate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_lrsdockwidget.py" line="498"/>
        <source>Output error field</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_lrsdockwidget.py" line="499"/>
        <source>Route field</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_lrsdockwidget.py" line="502"/>
        <source>Measure of punctual or start of linear event.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_lrsdockwidget.py" line="506"/>
        <source>End of linear event. Leave blank for punctual events.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_lrsdockwidget.py" line="503"/>
        <source>Start measure field</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_lrsdockwidget.py" line="504"/>
        <source>Events layer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_lrsdockwidget.py" line="510"/>
        <source>Output layer name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_lrsdockwidget.py" line="507"/>
        <source>End measure field</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_lrsdockwidget.py" line="508"/>
        <source>Events</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_lrsdockwidget.py" line="509"/>
        <source>Layer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_lrsdockwidget.py" line="511"/>
        <source>Output route field</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_lrsdockwidget.py" line="512"/>
        <source>Output measure field</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_lrsdockwidget.py" line="516"/>
        <source>Measures</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_lrsdockwidget.py" line="517"/>
        <source>Output table</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_lrsdockwidget.py" line="518"/>
        <source>PostGIS connection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_lrsdockwidget.py" line="519"/>
        <source>Output schema</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_lrsdockwidget.py" line="520"/>
        <source>Export</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_lrsdockwidget.py" line="521"/>
        <source>Statistics</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="lrsdockwidget.py" line="89"/>
        <source>All routes</source>
        <translation type="unfinished">Todas as direções</translation>
    </message>
    <message>
        <location filename="lrsdockwidget.py" line="89"/>
        <source>Include routes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="lrsdockwidget.py" line="89"/>
        <source>Exclude routes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="lrsdockwidget.py" line="95"/>
        <source>Mark as errors</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="lrsdockwidget.py" line="95"/>
        <source>Span by straight line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="lrsdockwidget.py" line="95"/>
        <source>Exclude</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>LrsError</name>
    <message>
        <location filename="error.py" line="91"/>
        <source>Duplicate line</source>
        <translation>Linha duplicada</translation>
    </message>
    <message>
        <location filename="error.py" line="92"/>
        <source>Duplicate point</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="error.py" line="93"/>
        <source>Fork</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="error.py" line="94"/>
        <source>Orphan point</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="error.py" line="95"/>
        <source>Out of threshold</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="error.py" line="96"/>
        <source>Not enough points</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="error.py" line="97"/>
        <source>Missing route id</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="error.py" line="98"/>
        <source>Missing measure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="error.py" line="99"/>
        <source>Cannot guess direction</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="error.py" line="100"/>
        <source>Wrong measure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="error.py" line="101"/>
        <source>Duplicate referencing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="error.py" line="102"/>
        <source>Parallel line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="error.py" line="103"/>
        <source>Fork line</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>LrsSelectionDialog</name>
    <message>
        <location filename="ui_selectiondialog.py" line="41"/>
        <source>LRS - routes selection</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
