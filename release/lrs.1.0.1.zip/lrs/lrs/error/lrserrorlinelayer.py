# -*- coding: utf-8 -*-
"""
/***************************************************************************
 LrsPlugin
                                 A QGIS plugin
 Linear reference system builder and editor
                              -------------------
        begin                : 2017-5-29
        copyright            : (C) 2017 by Radim Blažek
        email                : radim.blazek@gmail.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""
from .lrserrorlayer import LrsErrorLayer
from ..utils import crsString


class LrsErrorLineLayer(LrsErrorLayer):
    def __init__(self, crs):
        uri = "LineString?crs=%s" % crsString(crs)
        super(LrsErrorLineLayer, self).__init__(uri, 'LRS line errors')