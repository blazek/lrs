# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'ui_selectiondialog.ui'
#
# Created: Wed May 24 20:59:45 2017
#      by: PyQt5 UI code generator 5.3.2
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_LrsSelectionDialog(object):
    def setupUi(self, LrsSelectionDialog):
        LrsSelectionDialog.setObjectName("LrsSelectionDialog")
        LrsSelectionDialog.resize(400, 300)
        self.verticalLayout = QtWidgets.QVBoxLayout(LrsSelectionDialog)
        self.verticalLayout.setObjectName("verticalLayout")
        self.tableWidget = QtWidgets.QTableWidget(LrsSelectionDialog)
        self.tableWidget.setObjectName("tableWidget")
        self.tableWidget.setColumnCount(0)
        self.tableWidget.setRowCount(0)
        self.tableWidget.verticalHeader().setDefaultSectionSize(20)
        self.verticalLayout.addWidget(self.tableWidget)
        self.buttonBox = QtWidgets.QDialogButtonBox(LrsSelectionDialog)
        self.buttonBox.setOrientation(QtCore.Qt.Horizontal)
        self.buttonBox.setStandardButtons(QtWidgets.QDialogButtonBox.Cancel|QtWidgets.QDialogButtonBox.Ok)
        self.buttonBox.setObjectName("buttonBox")
        self.verticalLayout.addWidget(self.buttonBox)

        self.retranslateUi(LrsSelectionDialog)
        self.buttonBox.accepted.connect(LrsSelectionDialog.accept)
        self.buttonBox.rejected.connect(LrsSelectionDialog.reject)
        QtCore.QMetaObject.connectSlotsByName(LrsSelectionDialog)

    def retranslateUi(self, LrsSelectionDialog):
        _translate = QtCore.QCoreApplication.translate
        LrsSelectionDialog.setWindowTitle(_translate("LrsSelectionDialog", "LRS - routes selection"))

