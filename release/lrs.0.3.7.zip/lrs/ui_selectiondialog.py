# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'ui_selectiondialog.ui'
#
# Created: Wed Dec 18 13:42:34 2013
#      by: PyQt4 UI code generator 4.9.3
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    _fromUtf8 = lambda s: s

class Ui_LrsSelectionDialog(object):
    def setupUi(self, LrsSelectionDialog):
        LrsSelectionDialog.setObjectName(_fromUtf8("LrsSelectionDialog"))
        LrsSelectionDialog.resize(400, 300)
        self.verticalLayout = QtGui.QVBoxLayout(LrsSelectionDialog)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.tableWidget = QtGui.QTableWidget(LrsSelectionDialog)
        self.tableWidget.setObjectName(_fromUtf8("tableWidget"))
        self.tableWidget.setColumnCount(0)
        self.tableWidget.setRowCount(0)
        self.tableWidget.verticalHeader().setDefaultSectionSize(20)
        self.verticalLayout.addWidget(self.tableWidget)
        self.buttonBox = QtGui.QDialogButtonBox(LrsSelectionDialog)
        self.buttonBox.setOrientation(QtCore.Qt.Horizontal)
        self.buttonBox.setStandardButtons(QtGui.QDialogButtonBox.Cancel|QtGui.QDialogButtonBox.Ok)
        self.buttonBox.setObjectName(_fromUtf8("buttonBox"))
        self.verticalLayout.addWidget(self.buttonBox)

        self.retranslateUi(LrsSelectionDialog)
        QtCore.QObject.connect(self.buttonBox, QtCore.SIGNAL(_fromUtf8("accepted()")), LrsSelectionDialog.accept)
        QtCore.QObject.connect(self.buttonBox, QtCore.SIGNAL(_fromUtf8("rejected()")), LrsSelectionDialog.reject)
        QtCore.QMetaObject.connectSlotsByName(LrsSelectionDialog)

    def retranslateUi(self, LrsSelectionDialog):
        LrsSelectionDialog.setWindowTitle(QtGui.QApplication.translate("LrsSelectionDialog", "LRS - routes selection", None, QtGui.QApplication.UnicodeUTF8))

